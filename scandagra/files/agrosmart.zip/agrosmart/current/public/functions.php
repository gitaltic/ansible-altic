<?php

/**
 * @param $title
 * @param $string
 *
 * @return string
 */
function msgSuccess($title, $string)
{
    return sprintf("%s: %s", $title, CliColor::getColoredString($string, 'white', 'green'));
}

/**
 * @param $title
 * @param $string
 *
 * @return string
 */
function msgError($title, $string)
{
    return sprintf("%s: %s", $title, CliColor::getColoredString($string, 'white', 'red'));
}

/**
 * @return array
 */
function getRequiredPhpExtensions()
{
    return [
        'intl',
        'calendar',
        'bcmath',
        'ctype',
        'curl',
        'dom',
        'gd',
        'iconv',
        'json',
        'libxml',
        'mbstring',
        'pdo',
        'mysql',
        'SimpleXML',
        'soap',
        'SPL',
        'tokenizer',
        'xml',
        'xmlreader',
        'xmlrpc',
        'xmlwriter',
        'mcrypt',
        'zip',
        'IonCube Loader',
    ];
}

/**
 * @return string
 */
function git()
{
    exec("git --version", $output);

    return implode('<br />', $output);
}

/**
 * @return bool
 */
function gitInstalled()
{
    return strpos(git(), 'git') !== 0;
}

/**
 * @param $command
 *
 * @return bool
 */
function commandExist($command)
{
    return test("hash $command 2>/dev/null");
}

/**
 * @param $command
 *
 * @return bool
 */
function test($command)
{
    return exec("if $command; then echo 'true'; fi") === 'true';
}

/**
 * @return bool
 */
function isValidPhpVersion()
{
    return ((float)phpversion() == 5.6);
}

/**
 * @return bool
 */
function isEnabledShortPhpTags()
{
    return ini_get('short_open_tag') == 'On' || ini_get('short_open_tag') == 1;
}

/**
 * @return bool
 */
function isValidDateTimeZone()
{
    return ini_get('date.timezone') != '';
}

/**
 * @return bool
 */
function checkProcFunctions()
{
    $checkList = [
        'proc_open',
        'proc_close',
    ];
    $disabled = explode(',', ini_get('disable_functions'));
    foreach ($checkList as $item) {
        if (in_array($item, $disabled)) {
            return false;
        }
    }

    return true;
}

/**
 * @return bool
 */
function isEnabledApacheModRewrite()
{
    return (function_exists('apache_get_modules') && in_array('mod_rewrite', apache_get_modules()));
}
