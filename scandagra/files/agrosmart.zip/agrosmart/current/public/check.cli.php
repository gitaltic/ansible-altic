<?php
require_once __DIR__.'/CliColor.php';
require_once __DIR__.'/functions.php';

/**
 * @return mixed
 */
function checkExtensions()
{
    $extensions = getRequiredPhpExtensions();
    foreach ($extensions as $extension) {
        if (extension_loaded($extension)) {
            echo msgSuccess(sprintf("php ext: \e[4m%s\e[0m", $extension), 'OK');
        } else {
            echo msgError(sprintf("php ext: \e[4m%s\e[0m", $extension), 'NO');
        }
    }
}

echo CliColor::getColoredString('Check OS..', 'white', 'blue');
echo (commandExist('git')) ? msgSuccess('git', 'OK') : msgError('git', 'not installed (apt install git)');
echo (commandExist('getfacl')) ? msgSuccess('acl', 'OK') : msgError('acl', 'not installed (apt install acl)');
echo (commandExist('curl')) ? msgSuccess('cURL', 'OK') : msgError('cURL', 'not installed (apt install curl)');
echo (commandExist('zip')) ? msgSuccess('zip', 'OK') : msgError('zip', 'not installed (apt install zip)');
echo (commandExist('unzip')) ? msgSuccess('unzip', 'OK') : msgError('unzip', 'not installed (apt install unzip)');
echo CliColor::getColoredString('Check PHP...', 'white', 'blue');
echo (isValidPhpVersion()) ? msgSuccess('PHP version', phpversion()) : msgError('PHP version', phpversion());
echo (isEnabledShortPhpTags()) ? msgSuccess('short_open_tag', 'On') : msgError('short_open_tag', 'Off');
echo (checkProcFunctions()) ? msgSuccess('proc_open, proc_close', 'OK') : msgError('proc_open, proc_close', 'DISABLED');
echo (isValidDateTimeZone()) ? msgSuccess('date.timezone', ini_get('date.timezone')) :
    msgError('date.timezone', 'Empty date.timezone');
checkExtensions();
