<?php
require_once __DIR__.'/functions.php';
?>
    <html>
    <head>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    </head>
<body>

<div style="width: 410px; margin-left: auto; margin-right: auto; margin-top: 20px">
    <ul class="nav nav-pills nav-stacked">
        <li class="active">
            <a href="#">
                OS
            </a>
        </li>
        <li>
            <a href="#">
                Git
                <?php
                echo (!commandExist('git')) ?
                    '<span class="badge pull-right" style="background-color: red">not installed</strong>' :
                    '<span class="badge pull-right" style="background-color: green">OK</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                ACL
                <?php
                echo (!commandExist('getfacl')) ?
                    '<span class="badge pull-right" style="background-color: red">not installed</strong>' :
                    '<span class="badge pull-right" style="background-color: green">OK</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                cURL
                <?php
                echo (!commandExist('curl')) ?
                    '<span class="badge pull-right" style="background-color: red">not installed</strong>' :
                    '<span class="badge pull-right" style="background-color: green">OK</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                zip
                <?php
                echo (!commandExist('zip')) ?
                    '<span class="badge pull-right" style="background-color: red">not installed</strong>' :
                    '<span class="badge pull-right" style="background-color: green">OK</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                unzip
                <?php
                echo (!commandExist('unzip')) ?
                    '<span class="badge pull-right" style="background-color: red">not installed</strong>' :
                    '<span class="badge pull-right" style="background-color: green">OK</span>' ?>
            </a>
        </li>
        <li class="active">
            <a href="#">
                Apache
            </a>
        </li>
        <li>
            <a href="#">
                mod_rewrite
                <?php echo (isEnabledApacheModRewrite()) ?
                    '<span class="badge pull-right" style="background-color: green">OK</span>' :
                    '<span class="badge pull-right" style="background-color: red">NO</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                Override php settings ("AllowOverride all")
                <?php echo (ini_get('session.gc_maxlifetime') == '28800') ?
                    '<span class="badge pull-right" style="background-color: green">OK</span>' :
                    '<span class="badge pull-right" style="background-color: red">DISABLED</span>' ?>
            </a>
        </li>
        <li class="active">
            <a href="#">
                MySQL
            </a>
        </li>
        <li>
            <form role="form" method="post" class="form-inline">
                <div class="form-group">
                    <input type="text" name="uname" class="form-control"
                           value="<?php echo (!empty($_POST['uname'])) ? $_POST['uname'] : '' ?>"
                           placeholder="Username">
                    <input type="password" name="pass" class="form-control"
                           value="<?php echo (!empty($_POST['pass'])) ? $_POST['pass'] : '' ?>" placeholder="Password">
                    <button type="submit" class="btn btn-default">Try!</button>
                </div>
            </form>
            <?php if (!empty($_POST['uname']) && !empty($_POST['pass'])): ?>
                <?php echo checkMySql($_POST['uname'], $_POST['pass']); ?>
            <?php endif; ?>
        </li>
        <li class="active">
            <a href="#">
                PHP
            </a>
        </li>
        <li>
            <a href="#">
                Version
                <?php echo (isValidPhpVersion()) ?
                    '<span class="badge pull-right" style="background-color: green">'.phpversion().'</span>' :
                    '<span class="badge pull-right" style="background-color: red">5.6 ('.phpversion().')</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                short_open_tag
                <?php echo (isEnabledShortPhpTags()) ?
                    '<span class="badge pull-right" style="background-color: green">On</span>' :
                    '<span class="badge pull-right" style="background-color: red">Off</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                proc_open, proc_close
                <?php echo (checkProcFunctions()) ?
                    '<span class="badge pull-right" style="background-color: green">OK</span>' :
                    '<span class="badge pull-right" style="background-color: red">DISABLED</span>' ?>
            </a>
        </li>
        <li>
            <a href="#">
                date.timezone
                <?php echo (isValidDateTimeZone()) ?
                    '<span class="badge pull-right" style="background-color: green">OK</span>' :
                    '<span class="badge pull-right" style="background-color: red">Empty date.timezone setting</span>' ?>
            </a>
        </li>
        <li class="active">
            <a href="#">
                PHP Extensions
            </a>
        </li>
        <?php echo checkExtensions(); ?>
    </ul>
</div>

<?php

/**
 * @return string
 */
function checkExtensions()
{
    $template = '<li>
            <a href="#">
                %s
                <span class="badge pull-right" style="background-color: %s">%s</span>
            </a>
        </li>';

    $output = '';
    $extensions = getRequiredPhpExtensions();
    foreach ($extensions as $extension) {
        if (extension_loaded($extension)) {
            $output .= sprintf($template, $extension, 'green', 'OK');
        } else {
            $output .= sprintf($template, $extension, 'red', 'NO');
        }
    }

    return $output;
}
