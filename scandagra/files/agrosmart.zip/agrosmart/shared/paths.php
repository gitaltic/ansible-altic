<?php

// Define path to application directory
defined('ROOT_PATH') || define('ROOT_PATH', realpath(dirname(__FILE__)));

// Define path to application directory
defined('APP_PATH') || define('APP_PATH', realpath(ROOT_PATH . '/application'));

// Define application data dir
defined('DATA_PATH') || define('DATA_PATH', realpath(ROOT_PATH . '/../../assets'));

